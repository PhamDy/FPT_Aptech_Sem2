<?php $__env->startSection('content'); ?>
    <div class="container mt-5">
        <h2>Login</h2>


        <?php if(isset($title)): ?>
            <div class="alert alert-danger"><?php echo e($title); ?></div>
        <?php endif; ?>


        <form action="" method="post">
            <?php echo csrf_field(); ?>
            <div class="form-group">
                <label for="username">Username:</label>
                <input type="text" class="form-control" name="username" id="username" required>
            </div>
            <div class="form-group">
                <label for="password">Password:</label>
                <input type="password" class="form-control" name="password" id="password" required>
            </div>
            <button type="submit" class="btn btn-primary">Login</button>
        </form>

    </div>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\FPT Aptech\FPT_Aptech_Sem2\FPT_Aptech_Sem2\Php\Assignment\resources\views/login.blade.php ENDPATH**/ ?>