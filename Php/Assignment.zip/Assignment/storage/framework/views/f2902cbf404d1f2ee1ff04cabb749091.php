<?php $__env->startSection('content'); ?>
    <div class="container mt-5">
        <h2>Welcome List Book </h2>
        <div class="mb-5">
            <form action="" method="GET">
                <div class="input-group">
                    <input type="text" class="form-control" placeholder="Search by title..." name="search" id="search">
                    <button class="btn btn-outline-primary" type="submit">Search</button>
                </div>
            </form>
        </div>

        <div class="row mt-5">
            <?php $__currentLoopData = $books; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-4 mb-3">
                    <div class="card">
                        <img src="<?php echo e($book->img); ?>" class="card-img-top" alt="Product Image">
                        <div class="card-body">
                            <h5 class="card-title"><?php echo e($book->title); ?></h5>
                            <p class="card-text">Publishing year: <?php echo e($book->pub_year); ?></p>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\FPT Aptech\FPT_Aptech_Sem2\FPT_Aptech_Sem2\Php\Assignment\resources\views/books.blade.php ENDPATH**/ ?>